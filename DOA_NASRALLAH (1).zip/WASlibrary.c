/*
my name: DOA NASRALLAH
 * File: MS3functions.c
 * Author: V. Cavalli-Sforza
 * Project: What a Show! application
 * Milestone: 3, with the addition of discounts.
 * Contents: This file contains all major functions for the app.
 */

#include <stdio.h>

/* Program constants */

// price in dirhams of show 3

#define TAX_RATE 0.20 // tax on purchase
#define PROC_FEE 50
#define DISCOUNT15 0.15
#define DISCOUNT10 0.1
#define DISCOUNT5 0.05
#define MAX_NUMBER_OF_CUSTOMERS 2
#define MAX_NUMBER_OF_SHOWS 4 // processing fee (applied one)

/* Global variables, shared among many functions. */
unsigned short  qavail1 = 30, qavail2 = 20, qavail3 = 10, qavail4 = 9; // available quantity of seats for 4 shows

float ordered_quantity[MAX_NUMBER_OF_CUSTOMERS][MAX_NUMBER_OF_SHOWS];
float price[MAX_NUMBER_OF_SHOWS] = {100, 150, 200, 300},
      net_total_price[MAX_NUMBER_OF_CUSTOMERS],
      discount_amount[MAX_NUMBER_OF_CUSTOMERS],
      discounted_price[MAX_NUMBER_OF_CUSTOMERS],
      tax[MAX_NUMBER_OF_CUSTOMERS],
      total_price[MAX_NUMBER_OF_CUSTOMERS];

int show; 
// total seats ordered for all show,

// discount rates

/* Prototypes for functions used only locally. */
void _Greet_Customer();
void _Present_Shows();
void _Handle_Order(int ci, int show, unsigned short quantity);
void _Compute_Running_Totals(int ci, int show);
float _Compute_Discount_Rate(int ci, int show);

/* Initializes the available tickets for each show and the discount rates. */



/* Processes the orders for each customer with the help of other functions. */
void Handle_Customer(int ci)
{

    int feedback;
    unsigned short quantity, show; // quantity desired by user
    char ch;                          // used to clear the input

    /* Initialize totals for the user. */
    float net_total_price = 0.0;

    for (show = 0; show < 4; show++)
    {
        ordered_quantity[ci][show] = 0;
    }
    /* Greet the user. */
    _Greet_Customer();

    do
    {

        _Present_Shows();
        /* Ask the user for the show and the quantity of seats desired. */
        printf("\nWhich show do you want seats for? (1,2, 3 or 4): ");
        scanf("%hu", &show);


        if (show < 1 || show > 4)
        {
            printf("Sorry. The selected show does not exist. Try again.\n");
            /* Clear the input of any lingering characters. */
            do
                scanf("%c", &ch);
            while (ch != '\n');
            continue; // start from the top of the loop again
        }

        printf("Select quantity: ");
        while (scanf("%hu", &quantity) != 1)
        { // not a number
            printf("Sorry, that's an invalid quantity. Try again.\nSelect Quantity: ");
            /* Clear the input of any lingering characters. */
            do
                scanf("%c", &ch);
            while (ch != '\n');
        }

        if (quantity == 0)
        {
            printf("OK, 0 seats for show %hu.\n", show);
        }
        else
            _Handle_Order(ci, show, quantity); // handle current order

        /* Clear the input of any lingering characters. */
        do
            scanf("%c", &ch);
        while (ch != '\n');

        /* Then ask the user if they want to continue ordering. */
        printf("\nDo you want to order more seats? Type '1' to continue ordering': ");
        scanf("%d", &feedback);

    } while (feedback == 1);

    /* Clear the input of any lingering characters. */
    do
        scanf("%c", &ch);
    while (ch != '\n');

    printf("\nThank you, customer! Goodbye for now.\n");

}

/* Greet the customer. */
void _Greet_Customer()
{
    printf("\n-----------------------------------------------------------------------------------------\n");
    printf("Hello, customer!\n");
    printf("Welcome to What a Show!, the show ticket booking service that gives you the most choices.\n");
    printf("-----------------------------------------------------------------------------------------\n");
}

/* Present the shows and seats available. */
void _Present_Shows()
{
    printf("You can purchase seats for these shows:\n");
    printf("  (1) The Nutcracker ballet, with music by Pyotr Ilyich Tchaikovsky.\n");
    printf("      Available seats: %d\n", qavail1);
    printf("  (2) The play Hamlet, by William Shakespeare.\n");
    printf("      Available seats: %d\n", qavail2);
    printf("  (3) A concert by Kate Bush.\n");
    printf("      Available seats: %d\n", qavail3);
    printf("  (4) A comedian show by Mr.Bean.\n ");
    printf("      Available seats: %d\n", qavail4);
}
void print_report()
{
    /**
     * These are LOCAL variables. Their scope is limited to this function block.
     * ci: customer index, moves between 0 and n_customers.
     * pi: product index, moves between 0 and n_products.
     * lci: lowest-order customer index, keeps track of the customer with the lowest order.
     * hci: highest-order customer index, keeps track of the customer with the highest order.
     */
    int ci, show,lci = 0, hci = 0, grand_tckt = 0;
    float grand_net_total = 0.0, grand_tax = 0.0, grand_total = 0.0, grand_disc = 0,
    sum_tickets = 0, sum_ntp = 0, sum_discount = 0, sum_tax = 0, sum_tp = 0, average_tickets = 0, average_ntp = 0, average_discount = 0, average_tax = 0, average_tp = 0;

    printf("\n***REPORT**\n\n");

    for (ci = 0; ci < MAX_NUMBER_OF_CUSTOMERS; ci++)
    {
        printf("Customer %d\n-------------------------\n", ci + 1);
        for (show = 0; show < 4; show++)
        {
            if (ordered_quantity[ci][show] > 0)
            {
              printf("Show %d:\n", show + 1);
              printf("Tickets Purchased: %.1f\n", ordered_quantity[ci][show]);
              printf("Net Total Price: %.2f dhs\n", net_total_price[ci]);
              printf("Tax: %.2f dhs\n", tax[ci]);
              printf("Total Price: %.2f dhs\n\n", total_price[ci]);
                
            }
        }
        if (net_total_price[ci] < net_total_price[lci])
        {
            lci = ci;
        }
        else if (net_total_price[ci] > net_total_price[hci])
        {
            hci = ci;
        }
         if (ordered_quantity[ci][show] < ordered_quantity[lci][show])
        {
            lci = ci;
        }
        else if (ordered_quantity[ci][show] > ordered_quantity[hci][show])
        {
            hci = ci;
        }

        sum_tickets += ordered_quantity[ci][show];
        sum_discount += discounted_price[ci];
        sum_ntp += net_total_price[ci];
        sum_tax += tax[ci];
        sum_tp += total_price[ci];
        grand_tckt = ordered_quantity[ci][show];
        grand_disc += discounted_price[ci];     
        grand_net_total += net_total_price[ci];
        grand_tax += tax[ci];
        grand_total += total_price[ci];
       
    }
    average_discount = sum_discount / ci;
    average_ntp = sum_ntp / ci;
    average_tax = sum_tax / ci;
    average_tickets = sum_tickets / ci;
    average_tp = sum_tp / ci;

    
  
    printf("\n***Lowest-order Customer**\n\n");
    printf("Customer: %d\nNet Total Price: %.2fdhs\nTax: %.2fdhs\nTotal Price: %.2fdhs\n",
           lci + 1, net_total_price[lci],
           tax[lci], total_price[lci]);

    
  
  
  
    printf("\n***Highest-order Customer**\n");
    printf("Customer: %d\n\nNet Total Price: %.2fdhs\nTax: %.2fdhs\nTotal Price: %.2fdhs\n",
           hci + 1, net_total_price[hci],
           tax[hci], total_price[hci]);

    
  
  
    printf("\n***Lowest-order Ticket**\n\n"); 
    printf("Customer: %d\nTickets: %.1f\n",
           lci + 1, ordered_quantity[ci][show]);

    
  
  
    printf("\n***Highest-order Ticket**\n\n");
    printf("Customer: %d\nTickets: %.1f\n",
           hci + 1, ordered_quantity[ci][show]);

    
  
  
    printf("\n***Grand Total**\n\n");
    printf("Grand Net Total: %.2fdhs\nGrand Tax: %.2fdhs\nGrand Total: %.2fdhs\n",
           grand_net_total, grand_tax, grand_total);
    printf("Grand tickets: %d\nGrand discounted price: %.2fdhs\n",
     grand_tckt, grand_disc);

   
  
    printf("\n**AVERAGE**\n\n");
   printf("Tickets Average: %.2f\nNet Total Price Average: %.2fdhs\nDiscount Average: %.2f\nTax Average: %.2fdhs\nTotal Price Average: %.2f\n",
           average_tax, average_ntp, average_discount, average_tax, average_tp);


    
  
    printf("\n**STOCK**\n\n");

    printf("Show 1: %hu tickets\nShow 2: %hu tickets\nShow 3: %hu tickets\nShow 4: %hu tickets\n", qavail1, qavail2, qavail3, qavail4);
    printf("*****\n");

}



/**
 * Handle one customer ci.
 * ci: customer index.
 */
/* Checks quantity availability; if available it processes a partial order. */
void _Handle_Order(int ci, int show, unsigned short quantity)
{
    // for this order

    switch (show)
    {
    case 1:
        if (quantity <= qavail1)
        {
            show--;
            qavail1 -= quantity;
            net_total_price[ci] += price[show] * quantity;
            ordered_quantity[ci][show] += quantity;
            _Compute_Running_Totals(ci, show);
            break;
        }
        else
        {
            printf("Sorry, only %hu seats are available.\n", qavail1);
            return;
        }
    case 2:
        if (quantity <= qavail2)
        {
            show--;
            qavail2 -= quantity;
            net_total_price[ci] += price[show] * quantity;
            ordered_quantity[ci][show] += quantity;
            _Compute_Running_Totals(ci, show);
            break;
        }
        else
        {
            printf("Sorry, only %hu seats are available.\n", qavail2);
            return;
        }
    case 3:
        if (quantity <= qavail3)
        {
            show--;
            qavail3 -= quantity;
            net_total_price[ci] += price[show] * quantity;
            ordered_quantity[ci][show] += quantity;
            _Compute_Running_Totals(ci, show);
            break;
        }
        else
        {
            printf("Sorry, only %hu seats are available.\n", qavail3);
            return;
        }
    case 4:
        if (quantity <= qavail4)
        {
            show--;
            qavail4 -= quantity;
            net_total_price[ci] += price[show] * quantity;
            ordered_quantity[ci][show] += quantity;
            _Compute_Running_Totals(ci, show);
            break;
        }
        else
        {
            printf("Sorry, only %hu seats are available.\n", qavail4);
            return;
        }
    default:
        printf("This should never be printed.\n");
    }


}

void _Compute_Running_Totals(int ci, int show)
{
    float discount_rate = 0; // compute discount rate based on quantity
        // amount of discount in dh
            // net_total_price minus discount
               // tax amount based on discounted price
     // discounted price plus tax

    /* Compute discount rate based on current quantity*/

    discount_rate = _Compute_Discount_Rate(ci, show); // based on total quantity
    discount_amount[ci] = net_total_price[ci] * discount_rate;
    discounted_price[ci] = net_total_price[ci] - discount_amount[ci];

    /* Compute tax and total price.*/
    tax[ci] = discounted_price[ci] * TAX_RATE;
    total_price[ci] = discounted_price[ci] + tax[ci] + PROC_FEE;

    /* Confirm purchase with user. */
    if (discount_rate != 0.0)
    {
        printf("You received a discount of %.1f%% (%.2f dhs) because you purchased %.1f seats in total.\n",
               discount_rate * 100, discount_amount[ci], ordered_quantity[ci][show]);
        printf("The discounted price is %.2f dhs.\n", discounted_price[ci]);
    }

    printf("The tax is: %.2f dhs.\n", tax[ci]);
    printf("There is a low processing fee of %.2f dhs.\n", (float)PROC_FEE);
    printf("The total price sums to %.2f dhs.\n", total_price[ci]);
}

float _Compute_Discount_Rate(int ci, int show)
{  
    if (ordered_quantity[ci][show] >= 15)
    {return DISCOUNT15;}
    else if (ordered_quantity[ci][show] > 10 || ordered_quantity[ci][show] == 10)
    {return DISCOUNT10;}
    else if (ordered_quantity[ci][show] > 5 || ordered_quantity[ci][show] == 5)

    {return DISCOUNT5;}
    else
        return 0.0;
}