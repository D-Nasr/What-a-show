/** 
 * MY NAME : DOA NASRALLAH
* File: MS3main.c
* Author: V. Cavalli-Sforza
* Project: What a Show! application
* Milestone: 3, with the addition of discounts.
* Outline:
* There are 3 shows to choose from
  1. A dance performance (The Nutcracker, with music by Pyotr Ilyich Tchaikovsky). 
     Initially available tickets: 30; Price: 125.50 dh.
  2. A theatre performance (Hamlet, the play by William Shakespeare). 
     Initially available tickets: 20; Price: 175.50 dh.
  3. A music concert (Kate Bush). 
     Initially available tickets: 10; Price: 225.50 dh.
* Multiple customers call in and can place multiple orders.
* The number of customers is input b     y the operator at the start.
* The application asks each customer if they want to order more tickets.
* Prices and quantities available are defined constants.
* The discount rate should apply to the total number of tickets bought. 
* Tax is applied after discount. The processing fee is charged only once. 
*/

#include <stdio.h>
#include "WASheader.h"
#define MAX_NUMBER_OF_CUSTOMERS 2


int main (void) {
    int ci;



    for (ci=0; ci < MAX_NUMBER_OF_CUSTOMERS; ci++) {
        Handle_Customer(ci);
    }
    print_report();

    return 0;
}