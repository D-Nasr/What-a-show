/* 
MY NAME: DOA NASRALLAH
* File: MS3functions.h
* Author: V. Cavalli-Sforza
* Project: What a Show! application
* Milestone: 3, with the addition of discounts.
* Contents: This file is the header file for MS3functions.c
* It contains all functions needed by MS3main.c
*/


void Handle_Customer(int ci);
void print_report();