//My name: Doa Nasrallah

#include <stdio.h>
//defining constants for 
#define ROWS 10
#define COLS 55

// Function prototypes
void num0(int pos);
void num1(int pos);
void num2(int pos);
void num3(int pos);
void num4(int pos);
void num5(int pos);
void num6(int pos);
void num7(int pos);
void num8(int pos);
void num9(int pos);

//the 2d array
char canva[ROWS][COLS];

// Function definitions
// Define num functions
void num0(int pos)
{
  for (int i = 0; i < 10; i++)
  {
    for (int j = 0; j < 1; j++)
    {
      canva[i][pos + j] = ' ';
    }
  }

  for (int i = 1; i < 11; i++)
  {
    canva[0][pos + i] = '0';
    canva[1][pos + i] = '0';

    canva[8][pos + i] = '0';
    canva[9][pos + i] = '0';
  }

  for (int k = 2; k < 8; k++)
  {
    for (int j = 1; j < 4; j++)
    {
      canva[k][pos + j] = '0';
    }

    for (int y = 7; y < 10; y++)
    {
      canva[k][pos + y] = '0';
    }
  }

  // space between the digits
  for (int l = 0; l < 10; l++)
  {
    for (int p = 10; p < 12; p++)
    {
      canva[l][pos + p] = ' '; // printing the spaces between the digits
    }
  }
}

void num1(int pos)
{

  for (int i = 0; i < 10; i++)
  {
    for (int j = 0; j < 3; j++)
    {
      canva[i][pos + j] = ' ';
    }
  }
  for (int i = 0; i < 10; i++)
  {
    for (int j = 3; j < 6; j++)
    {
      canva[i][pos + j] = '1';
    }
  }

  for (int l = 0; l < 10; l++)
  {
    for (int p = 6; p < 9; p++)
    {
      canva[l][pos + p] = ' ';
    }
  }
}

void num2(int pos)
{

  for (int i = 0; i < 10; i++)
  {
    for (int j = 0; j < 1; j++)
    {
      canva[i][pos + j] = ' ';
    }
  }

  for (int i = 1; i < 11; i++)
  {
    canva[0][pos + i] = '2';
    canva[1][pos + i] = '2';
    canva[4][pos + i] = '2';
    canva[5][pos + i] = '2';
    canva[8][pos + i] = '2';
    canva[9][pos + i] = '2';
  }

  for (int k = 2; k < 4; k++)
  {

    for (int h = 7; h < 10; h++)
    {
      canva[k][pos + h] = '2';
    }
  }

  for (int k = 6; k < 8; k++)
  {
    for (int j = 1; j < 4; j++)
    {
      canva[k][pos + j] = '2';
    }
  }

  // space between the digits
  for (int l = 0; l < 10; l++)
  {
    for (int p = 10; p < 12; p++)
    {
      canva[l][pos + p] = ' '; // printing the spaces between the digits
    }
  }
}

void num3(int pos)
{

  for (int i = 0; i < 10; i++)
  {
    for (int j = 0; j < 1; j++)
    {
      canva[i][pos + j] = ' ';
    }
  }

  for (int i = 1; i < 11; i++)
  {
    canva[0][pos + i] = '3';
    canva[1][pos + i] = '3';
    canva[4][pos + i] = '3';
    canva[5][pos + i] = '3';
    canva[8][pos + i] = '3';
    canva[9][pos + i] = '3';
  }

  for (int k = 2; k < 4; k++)
  {

    for (int h = 7; h < 10; h++)
    {
      canva[k][pos + h] = '3';
    }
  }

  for (int k = 6; k < 8; k++)
  {

    for (int h = 7; h < 10; h++)
    {
      canva[k][pos + h] = '3';
    }
  }

  // space between the digits
  for (int l = 0; l < 10; l++)
  {
    for (int p = 10; p < 12; p++)
    {
      canva[l][pos + p] = ' '; // printing the spaces between the digits
    }
  }
}

void num4(int pos)
{

  for (int i = 0; i < 10; i++)
  {
    for (int j = 0; j < 1; j++)
    {
      canva[i][pos + j] = ' ';
    }
  }

  for (int i = 0; i < 4; i++)
  {
    for (int j = 1; j < 4; j++)
    {

      canva[i][pos + j] = '4';
    }
  }

  for (int k = 4; k < 6; k++)
  {
    for (int j = 1; j < 4; j++)
    {
      canva[k][pos + j] = '4';
    }

    for (int y = 7; y < 10; y++)
    {
      canva[k][pos + y] = '4';
    }
  }

  for (int i = 1; i < 10; i++)
  {
    canva[6][pos + i] = '4';
    canva[7][pos + i] = '4';
  }

  for (int k = 8; k < 10; k++)
  {
    for (int h = 7; h < 10; h++)
    {
      canva[k][pos + h] = '4';
    }
  }

  // space between the digits
  for (int l = 0; l < 10; l++)
  {
    for (int p = 10; p < 12; p++)
    {
      canva[l][pos + p] = ' '; // printing the spaces between the digits
    }
  }
}

void num5(int pos)
{

  for (int i = 0; i < 10; i++)
  {
    for (int j = 0; j < 1; j++)
    {
      canva[i][pos + j] = ' ';
    }
  }

  for (int i = 1; i < 11; i++)
  {
    canva[0][pos + i] = '5';
    canva[1][pos + i] = '5';
    canva[4][pos + i] = '5';
    canva[5][pos + i] = '5';
    canva[8][pos + i] = '5';
    canva[9][pos + i] = '5';
  }

  for (int k = 2; k < 4; k++)
  {
    for (int j = 1; j < 4; j++)
    {
      canva[k][pos + j] = '5';
    }
  }

  for (int k = 6; k < 8; k++)
  {

    for (int h = 7; h < 10; h++)
    {
      canva[k][pos + h] = '5';
    }
  }

  // space between the digits
  for (int l = 0; l < 10; l++)
  {
    for (int p = 10; p < 12; p++)
    {
      canva[l][pos + p] = ' '; // printing the spaces between the digits
    }
  }
}

void num6(int pos)
{

  for (int i = 0; i < 10; i++)
  {
    for (int j = 0; j < 1; j++)
    {
      canva[i][pos + j] = ' ';
    }
  }

  for (int i = 0; i < 4; i++)
  {
    for (int j = 1; j < 4; j++)
    {
      canva[i][pos + j] = '6';
    }
  }

  for (int i = 1; i < 10; i++)
  {
    canva[4][pos + i] = '6';
    canva[5][pos + i] = '6';
    canva[8][pos + i] = '6';
    canva[9][pos + i] = '6';
  }

  for (int k = 6; k < 8; k++)
  {
    for (int j = 1; j < 4; j++)
    {
      canva[k][pos + j] = '6';
    }

    for (int y = 7; y < 10; y++)
    {
      canva[k][pos + y] = '6';
    }
  }

  // space between the digits
  for (int l = 0; l < 10; l++)
  {
    for (int p = 10; p < 12; p++)
    {
      canva[l][pos + p] = ' '; // printing the spaces between the digits
    }
  }
}

void num7(int pos)
{

  for (int i = 0; i < 10; i++)
  {
    for (int j = 0; j < 1; j++)
    {
      canva[i][pos + j] = ' ';
    }
  }

  for (int i = 1; i < 10; i++)
  {
    canva[0][pos + i] = '7';
    canva[1][pos + i] = '7';
  }

  for (int i = 2; i < 10; i++)
  {

    for (int j = 7; j < 10; j++)
    {
      canva[i][pos + j] = '7';
    }
  }

  for (int l = 0; l < 10; l++)
  {
    for (int p = 10; p < 12; p++)
    {
      canva[l][pos + p] = ' '; // printing the spaces between the digits
    }
  }
}

void num8(int pos)
{

  for (int i = 0; i < 10; i++)
  {
    for (int j = 0; j < 1; j++)
    {
      canva[i][pos + j] = ' ';
    }
  }

  for (int i = 1; i < 10; i++)
  {
    canva[0][pos + i] = '8';
    canva[1][pos + i] = '8';
    canva[4][pos + i] = '8';
    canva[5][pos + i] = '8';
    canva[8][pos + i] = '8';
    canva[9][pos + i] = '8';
  }

  for (int k = 2; k < 4; k++)
  {
    for (int j = 1; j < 4; j++)
    {
      canva[k][pos + j] = '8';
    }

    for (int y = 7; y < 10; y++)
    {
      canva[k][pos + y] = '8';
    }
  }

  for (int k = 6; k < 8; k++)
  {
    for (int j = 1; j < 4; j++)
    {
      canva[k][pos + j] = '8';
    }

    for (int y = 7; y < 10; y++)
    {
      canva[k][pos + y] = '8';
    }
  }

  // space between the digits
  for (int l = 0; l < 10; l++)
  {
    for (int p = 10; p < 12; p++)
    {
      canva[l][pos + p] = ' '; // printing the spaces between the digits
    }
  }
}

void num9(int pos)
{

  for (int i = 0; i < 10; i++)
  {
    for (int j = 0; j < 1; j++)
    {
      canva[i][pos + j] = ' ';
    }
  }

  for (int i = 1; i < 10; i++)
  {
    canva[0][pos + i] = '9';
    canva[1][pos + i] = '9';
    canva[4][pos + i] = '9';
    canva[5][pos + i] = '9';
  }

  for (int k = 2; k < 4; k++)
  {
    for (int j = 1; j < 4; j++)
    {
      canva[k][pos + j] = '9';
    }

    for (int y = 7; y < 10; y++)
    {
      canva[k][pos + y] = '9';
    }
  }

  for (int i = 6; i < 10; i++)
  {

    for (int j = 7; j < 10; j++)
    {
      canva[i][pos + j] = '9';
    }
  }

  for (int l = 0; l < 10; l++)
  {
    for (int p = 10; p < 12; p++)
    {
      canva[l][pos + p] = ' '; // printing the spaces between the digits
    }
  }
}

void printCanvas()
{
  for (int i = 0; i < ROWS; i++)
  {
    for (int j = 0; j < COLS; j++)
    {
      printf("%c", canva[i][j]);
    }
    printf("\n");
  }
}

void clearCanvas()
{
  for (int i = 0; i < ROWS; i++)
  {
    for (int j = 0; j < COLS; j++)
    {
      canva[i][j] = ' ';
    }
  }
}

void check(int arr[], int size)
{
  printf("\n");
  clearCanvas();

  int pos = 0;
  for (int i = 0; i < size; i++)
  {
    if (arr[i] == 0)
    {
      num0(pos);
    }
    else if (arr[i] == 1)
    {
      num1(pos);
    }
    else if (arr[i] == 2)
    {
      num2(pos);
    }
    else if (arr[i] == 3)
    {
      num3(pos);
    }
    else if (arr[i] == 4)
    {
      num4(pos);
    }
    else if (arr[i] == 5)
    {
      num5(pos);
    }
    else if (arr[i] == 6)
    {
      num6(pos);
    }
    else if (arr[i] == 7)
    {
      num7(pos);
    }
    else if (arr[i] == 8)
    {
      num8(pos);
    }
    else if (arr[i] == 9)
    {
      num9(pos);
    }

    pos += 11; // Adjust the position for the next number
  }

  printCanvas();
}
