#include <stdio.h>
#include "BNdrawing.h"

int main() {
    int number, temp, count = 0;

    printf("Enter a number (maximum of 5 digits): \n");
    scanf("%d", &number);
    if (number < 0) {
      number = number * -1;}
    // Check if the number is within the allowed range
    if (number > 99999) {
        printf("Please enter a number with a maximum of 5 digits.\n");
        return 1; // Exit the program with an error status
    }

    temp = number;

    // Counting number of digits
    while (temp != 0) {
        temp /= 10;
        count++;
    }

    int numbers[count]; // Declare an array to hold digits
    temp = number;
    int index = count - 1; // Index for the array

    // Storing digits in the array in the original order
    while (temp != 0) {
        numbers[index] = temp % 10;
        temp /= 10;
        index--;
    }

  printf("The digits of the number are: ");
  printf("\n");
  
  check(numbers, count);
    return 0;
}
