

void cal_total_price();
void stock_and_price();
void custumer_orders();
int quantity_checker();