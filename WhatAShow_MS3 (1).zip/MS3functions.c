#include <stdio.h>
#define TAX 0.2


unsigned short available_quantity1, available_quantity2, available_quantity3;
float price_1, price_2, price_3, net_total_price;

void cal_total_price();
int quantity_checker(int quantity, unsigned short index, unsigned short available_quantity1,unsigned short available_quantity2,unsigned short available_quantity3,
float price_1,float price_2,float price_3);

void stock_and_price()
{
    printf("--------New stock-----------\n");
    printf("Enter the available quantity of product 1: ");
    scanf("%hu", &available_quantity1);
    printf("Enter the price of product 1: ");
    scanf("%f", &price_1);

    printf("Enter the available quantity of product 2: ");
    scanf("%hu", &available_quantity2);
    printf("Enter the price of product 2: ");
    scanf("%f", &price_2);

    printf("Enter the available quantity of product 3: ");
    scanf("%hu", &available_quantity3);
    printf("Enter the price of product 3: ");
    scanf("%f", &price_3);
}

/////////////////////////////////////////////////////////////////////

void custumer_orders()
{
    int feedback, net_total_price = 0, tickets;
    unsigned short index, quantity;

    printf("hello, and welcome to 'what a show', where you find your favorite things to watch. Here's the current available shows you can choose from :\n");
    printf("1. A dance performance (the Nutcracker, with music by Pyotr Ilyich Tchaikovsky)\n");
    printf("2. A theatre performance (Hamlet, the play by William Shakespeare)\n");
    printf("3. A music concert (Kate Bush)\n");

    printf("Choose from the list above which show you want to book (type 1, 2 or 3)");
    scanf("%hu", &index);

    printf("Please, enter the number of tickets you want for show %hu: \n", index);
    scanf("%hu", &quantity);

    quantity_checker(quantity, index, available_quantity1, available_quantity2, available_quantity3, price_1, price_2, price_3);

}

////////////////////////////////////////////////////////////////////////

int quantity_checker(int quantity, unsigned short index, unsigned short available_quantity1,unsigned short available_quantity2,unsigned short available_quantity3,
float price_1,float price_2,float price_3)
{
    int feedback, initial_total_price,
    total_price, discount, PRICE, tickets;

    switch (index)
    {
    case 1:
        if (quantity == 0)
        {

            printf("thank you for visiting, hope to see you again!\n ");
            tickets = tickets + quantity;
        }
        if (quantity > 0 && quantity <= available_quantity1)
        {

            initial_total_price = price_1 * quantity;
            PRICE = PRICE + initial_total_price;
            tickets = tickets + quantity;
            available_quantity1 = available_quantity1 - quantity;
        }
        else if (quantity > available_quantity1)
        {

            printf("sorry the wanted quantity is not available!!\n");
        }
        break;
    case 2:
        if (quantity == 0)
        {

            printf("thank you for visiting, hope to see you again!\n ");
            tickets = tickets + quantity;
        }
        if (quantity > 0 && quantity <= available_quantity2)
        {

            initial_total_price = price_2 * quantity;
            PRICE = PRICE + initial_total_price;
            tickets = tickets + quantity;
            available_quantity2 = available_quantity2 - quantity;
        }
        else if (quantity > available_quantity2)
        {

            printf("sorry the wanted quantity is not available!!\n");
        }
        break;
    case 3:
        if (quantity == 0)
        {

            printf("thank you for visiting, hope to see you again!\n ");
            tickets = tickets + quantity;
        }
        if (quantity > 0 && quantity <= available_quantity3)
        {

            initial_total_price = price_3 * quantity;
            PRICE = PRICE + initial_total_price;
            tickets = tickets + quantity;
            available_quantity3 = available_quantity3 - quantity;
        }
        else if (quantity > available_quantity3)
        {

            printf("sorry the wanted quantity is not available!!\n");
        }
        break;

    default:
        printf("Sorry, there is no such show. Please select from the available show (1,2 or 3)\n");
        tickets = tickets + 0;
        break;
    }

    return tickets;

    
}

/////////////////////////////////////////////////////////////////

void cal_total_price(int tickets, int PRICE)
{
    float initial_total_price, total_price, discount, tax;
    int processing_fee = 50;
    float discount_1 = 0.05, discount_2 = 0.10, discount_3 = 0.15;

    if (tickets < 0 || tickets == 0)
    {

        printf("thank you for visiting, hope to see you again!\n ");
    }
    else if (tickets > 0 && tickets < 5)
    {

        net_total_price = PRICE;
        tax = net_total_price * TAX;
        total_price = net_total_price + tax + processing_fee;

        printf("\nNet Total Price: %.2f dhs.\n", net_total_price);
        printf("Tax: %.2f dhs.\n", tax);
        printf("Total Price: %.2f dhs.\n", total_price);
        printf("Thank you for your purchase, hope to see you again!");
    }
    else if (tickets >= 5 && tickets <= 9)
    {

        discount = PRICE * discount_1;
        net_total_price = PRICE - discount;
        tax = net_total_price * TAX;
        total_price = net_total_price + tax + processing_fee;

        printf("\nNet Total Price: %.2f dhs.\n", net_total_price);
        printf("Discount : %.2f dhs \n", discount);
        printf("Tax: %.2f dhs.\n", tax);
        printf("Total Price: %.2f dhs.\n", total_price);
        printf("Thank you for your purchase, hope to see you again!");
    }
    else if (tickets >= 10 && tickets <= 14)
    {

        discount = PRICE * discount_2;
        net_total_price = PRICE - discount;
        tax = net_total_price * TAX;
        total_price = net_total_price + tax + processing_fee;

        printf("\nNet Total Price: %.2f dhs.\n", net_total_price);
        printf("Discount : %.2f dhs \n", discount);
        printf("Tax: %.2f dhs.\n", tax);
        printf("Total Price: %.2f dhs.\n", total_price);
        printf("Thank you for your purchase, hope to see you again!");
    }
    else if (tickets >= 15)
    {

        discount = PRICE * discount_3;
        net_total_price = PRICE - discount;
        tax = net_total_price * TAX;
        total_price = net_total_price + tax + processing_fee;

        printf("\nNet Total Price: %.2f dhs.\n", net_total_price);
        printf("Discount : %.2f dhs \n", discount);
        printf("Tax: %.2f dhs.\n", tax);
        printf("Total Price: %.2f dhs.\n", total_price);
        printf("Thank you for your purchase, hope to see you again!");
    }
}
