#include <stdio.h>
#include "MS3functions.h"

int main(void)
{
    int k, n, customer_limit, feedback;

    stock_and_price();

    printf("\nHow many customers do you want to handle?: ");
    scanf("%d", &customer_limit);

    for(k = 0; k< customer_limit; k++)
    {
        do {
        custumer_orders();
        printf("Do you want to repurchase tickets from a show again? (if yes type 1, if no type 2): \n");
        scanf("%hu", &feedback);
        } while (feedback == 1);


    }

    cal_total_price(quantity_checker);

    return 0;
}
